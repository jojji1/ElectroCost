package net.joji.electrocost;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.Locale;

public class HomeFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        EditText solution = view.findViewById(R.id.solution_screen);
        EditText rebateInput = view.findViewById(R.id.rebate_screen);
        TextView answer = view.findViewById(R.id.answer_screen);
        TextView rebateTotal = view.findViewById(R.id.rebate_total);
        TextView lastTotal = view.findViewById(R.id.total_screen);
        MaterialButton calcBtn = view.findViewById(R.id.calc_button);

        Toolbar myToolbar = view.findViewById(R.id.toolbar);
        myToolbar.setTitle("ElectroCost");

        calcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dataValue = solution.getText().toString();
                String dataRebate = rebateInput.getText().toString().trim();

                if (dataValue.isEmpty()) {
                    Toast.makeText(getActivity(), "Kindly input Watt's total value.", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (dataRebate.isEmpty()) {
                    Toast.makeText(getActivity(), "Kindly input the value of the rebate.", Toast.LENGTH_SHORT).show();
                    return;
                }

                double solutionValue;
                double rebateValue;
                try {
                    solutionValue = Double.parseDouble(dataValue);
                    rebateValue = Double.parseDouble(dataRebate);
                } catch (NumberFormatException e) {
                    Toast.makeText(getActivity(), "Incorrect input; please enter a number", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (rebateValue < 0 || rebateValue > 5) {
                    Toast.makeText(getActivity(), "The rebate amount must fall between 0% and 5%.a", Toast.LENGTH_SHORT).show();
                    return;
                }

                double total1, total2, total3, total4, finalTotal, rebateFinal;

                if (solutionValue <= 200) {
                    total1 = solutionValue * 0.218;
                    finalTotal = total1;
                } else if (solutionValue <= 300) {
                    total1 = 200 * 0.218;
                    total2 = (solutionValue - 200) * 0.334;
                    finalTotal = total1 + total2;
                } else if (solutionValue <= 600) {
                    total1 = 200 * 0.218;
                    total2 = 100 * 0.334;
                    total3 = (solutionValue - 300) * 0.516;
                    finalTotal = total1 + total2 + total3;
                } else {
                    total1 = 200 * 0.218;
                    total2 = 100 * 0.334;
                    total3 = 300 * 0.516;
                    total4 = (solutionValue - 600) * 0.546;
                    finalTotal = total1 + total2 + total3 + total4;
                }

                rebateFinal = finalTotal * (rebateValue / 100);
                double totalAfterRebate = finalTotal - rebateFinal;

                String formattedFinalTotal = String.format(Locale.getDefault(), "%.2f", finalTotal);
                String formattedRebateTotal = String.format(Locale.getDefault(), "%.2f", rebateFinal);
                String formattedLastTotal = String.format(Locale.getDefault(), "%.2f", totalAfterRebate);

                answer.setText(formattedFinalTotal);
                rebateTotal.setText(formattedRebateTotal);
                lastTotal.setText(formattedLastTotal);
            }
        });

        return view;
    }
}
